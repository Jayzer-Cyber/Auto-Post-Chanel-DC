import os
import re
import sys
import termios
import tty
import unicodedata
from colorama import Fore

_SESI_AKTIF = False


def reset_frame_input():
    global _SESI_AKTIF
    _SESI_AKTIF = False


def _cw(ch):
    if unicodedata.combining(ch) or ch == "\ufe0f":
        return 0
    if ord(ch) >= 0x2600:
        return 1
    return 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1


def _bungkus_prompt_dan_isi(prompt_str, isi_str, maks_lebar=48):
    token = []
    i = 0
    ansi_aktif = ""
    while i < len(prompt_str):
        if prompt_str[i] == "\033":
            m = re.match(r"\033\[[0-9;]*[mGK]", prompt_str[i:])
            if m:
                ansi_aktif = m.group(0)
                i += len(ansi_aktif)
                continue
        token.append((prompt_str[i], ansi_aktif, _cw(prompt_str[i])))
        i += 1

    for ch in isi_str:
        token.append((ch, Fore.WHITE, _cw(ch)))

    baris_list = []
    baris_ini = ""
    lebar_ini = 0
    warna_terakhir = ""

    for ch, warna, w in token:
        if lebar_ini + w > maks_lebar:
            baris_list.append((baris_ini + Fore.RESET, lebar_ini))
            baris_ini = "  "
            lebar_ini = 2
            warna_terakhir = ""
        if warna != warna_terakhir:
            baris_ini += warna
            warna_terakhir = warna
        baris_ini += ch
        lebar_ini += w

    baris_list.append((baris_ini + Fore.RESET, lebar_ini))
    return baris_list


def input_menyatu(prompt="", lanjut_frame=True):
    global _SESI_AKTIF
    bersih_prompt = prompt.strip("\r\n")

    sambung = lanjut_frame and _SESI_AKTIF
    _SESI_AKTIF = lanjut_frame

    if sambung:
        sys.stdout.write(f"\033[1A\r{Fore.CYAN}╟──────────────────────────────────────────────────╢\033[J\n")
    else:
        sys.stdout.write(f"\r{Fore.CYAN}╔══════════════════════════════════════════════════╗\033[J\n")
    sys.stdout.flush()

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    buf = []
    n_baris_lama = 0

    def _render_blok():
        nonlocal n_baris_lama
        isi = "".join(buf)
        baris_list = _bungkus_prompt_dan_isi(bersih_prompt, isi, maks_lebar=48)

        # Kursor saat ini selalu berada di baris terakhir dari blok sebelumnya (karena akhir render selalu \033[1A)
        # Jadi untuk kembali ke baris pertama blok konten, cukup naik (n_baris_lama - 1) baris!
        if n_baris_lama > 1:
            sys.stdout.write(f"\033[{n_baris_lama - 1}A")
        sys.stdout.write("\r\033[J")

        out = []
        for teks_baris, lebar_b in baris_list:
            sisa_b = max(0, 48 - lebar_b)
            out.append(f"{Fore.CYAN}║ {teks_baris}{' ' * sisa_b}{Fore.CYAN} ║\033[K")
        out.append(f"{Fore.CYAN}╚══════════════════════════════════════════════════╝\033[K")

        _, lebar_terakhir = baris_list[-1]
        kolom_kursor = min(51, 3 + lebar_terakhir)

        sys.stdout.write("\n".join(out) + f"\033[1A\033[{kolom_kursor}G")
        sys.stdout.flush()
        n_baris_lama = len(baris_list)

    try:
        tty.setcbreak(fd)
        _render_blok()

        while True:
            ch = os.read(fd, 32).decode("utf-8", errors="ignore")
            if not ch:
                continue
            selesai = False
            for c in ch:
                if c in ("\r", "\n"):
                    selesai = True
                    break
                elif c in ("\x7f", "\b"):
                    if buf:
                        buf.pop()
                elif c == "\x03":
                    raise KeyboardInterrupt
                elif c.isprintable():
                    buf.append(c)
            _render_blok()
            if selesai:
                break
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    sys.stdout.write("\r\n")
    sys.stdout.flush()
    return "".join(buf)
