import fcntl
import io
import os
import select
import sys
import termios
import threading
import tty

BG_STATE = {
    "aktif": False,
    "layar_auto": True,
    "stop_event": threading.Event(),
    "thread": None,
    "input_buf": "",
}

_ORIG_TERMIOS = None


class _SmartStdout(io.TextIOBase):
    def __init__(self, orig):
        self._orig = orig

    def write(self, s):
        if threading.current_thread().name == "AutoPostWorker" and not BG_STATE["layar_auto"]:
            return len(s)
        return self._orig.write(s)

    def flush(self):
        if threading.current_thread().name == "AutoPostWorker" and not BG_STATE["layar_auto"]:
            return
        self._orig.flush()

    def isatty(self):
        return self._orig.isatty()


def pasang_smart_stdout():
    if not isinstance(sys.stdout, _SmartStdout):
        sys.stdout = _SmartStdout(sys.stdout)


def aktifkan_mode_ketik_langsung():
    global _ORIG_TERMIOS
    try:
        fd = sys.stdin.fileno()
        if _ORIG_TERMIOS is None:
            _ORIG_TERMIOS = termios.tcgetattr(fd)
        tty.setcbreak(fd)
    except Exception:
        pass


def pulihkan_mode_terminal():
    global _ORIG_TERMIOS
    try:
        if _ORIG_TERMIOS is not None:
            fd = sys.stdin.fileno()
            termios.tcsetattr(fd, termios.TCSADRAIN, _ORIG_TERMIOS)
            _ORIG_TERMIOS = None
    except Exception:
        pass


def bersihkan_buffer_stdin():
    BG_STATE["input_buf"] = ""
    try:
        fd = sys.stdin.fileno()
        fl = fcntl.fcntl(fd, fcntl.F_GETFL)
        fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
        try:
            os.read(fd, 1024)
        except Exception:
            pass
        fcntl.fcntl(fd, fcntl.F_SETFL, fl)
    except Exception:
        pass


def baca_tombol_nonblock():
    aktifkan_mode_ketik_langsung()
    try:
        fd = sys.stdin.fileno()
        rlist, _, _ = select.select([fd], [], [], 0)
        if not rlist:
            return None

        data = os.read(fd, 64).decode("utf-8", errors="ignore")
        for ch in data:
            if ch in ("\r", "\n"):
                cmd = BG_STATE["input_buf"].strip().lower()
                BG_STATE["input_buf"] = ""
                if cmd == "m":
                    pulihkan_mode_terminal()
                    return "m"
                elif cmd in ("0", "q"):
                    pulihkan_mode_terminal()
                    return "q"
            elif ch in ("\x7f", "\b"):
                BG_STATE["input_buf"] = BG_STATE["input_buf"][:-1]
            elif ch.isprintable() and len(BG_STATE["input_buf"]) < 10:
                BG_STATE["input_buf"] += ch
    except Exception:
        pass
    return None
