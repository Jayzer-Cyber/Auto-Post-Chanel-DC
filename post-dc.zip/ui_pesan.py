import json, os, re, unicodedata

C_RESET, C_BOLD, C_DIM = "\033[0m", "\033[1m", "\033[2m"
C_CYAN, C_BLUE, C_GREEN = "\033[96m", "\033[94m", "\033[92m"
C_YELLOW, C_RED, C_WHITE, C_GRAY = "\033[93m", "\033[91m", "\033[97m", "\033[90m"

def vw(t):
    c = re.sub(r'\033\[[0-9;]*m', '', t)
    w = 0
    for x in c:
        if unicodedata.combining(x) or x == '\ufe0f': continue
        w += 2 if unicodedata.east_asian_width(x) in ('W', 'F') else 1
    return w

def pad(t, w):
    return t + (" " * max(0, w - vw(t)))

def trunc(t, mw):
    if vw(t) <= mw: return t
    o, w = "", 0
    for x in t:
        if unicodedata.combining(x) or x == '\ufe0f': o += x; continue
        cw = 2 if unicodedata.east_asian_width(x) in ('W', 'F') else 1
        if w + cw > mw: return o
        o += x; w += cw
    return o

def clean_name(s):
    return re.sub(r'^\d+[_\-\s]*', '', os.path.splitext(s)[0]).strip()

def load_cfg():
    if os.path.exists("config.json"):
        try: return json.load(open("config.json", encoding="utf-8"))
        except Exception: pass
    return {"channels": {}}

def count_chid(cfg, rel_path):
    return sum(1 for v in cfg.get("channels", {}).values() if v.get("file") == rel_path)

_STRUKTUR_DEFAULT = {'00_⭐・Custom': [], '01_📺・Advertising Section': ['01_🌟・vip-lounge-1.txt', '02_👥・find-suppliers.txt', '03_💎・bfg-promoting.txt', '04_⛽・bbm-promoting.txt', '05_🌐・worlds-promoting.txt', '06_🌱・ssp-shop-promoting.txt', '07_🥜・rsp-shop-promoting.txt', '08_🏷️・auction-promoting.txt'], '02_💎・High-Class Section': ['🌟・vip-lounge-2.txt', '🍏・buy-sell-growtokens.txt', '👑・buy-sell-rare-items.txt', '💄・buy-sell-subscriptions.txt', '🔮・buy-sell-iots.txt', '🦉・buy-sell-legendary.txt', '🧊・buy-sell-unobtainable.txt', '🧞・buy-sell-marvelous.txt'], '03_🏰・Guilds Section': ['🌟・vip-lounge-3.txt', '🏆・buy-sell-clash-items.txt', '💽・buy-sell-guilds.txt', '🔑・guild-advertising.txt', '🤼・buy-sell-daily-challenge.txt', '🪓・buy-sell-anomalizing.txt'], '04_🎉・Annual Events Section': ['⛄・buy-sell-winterfest.txt', '🌑・buy-sell-harvest-festival.txt', '🌞・buy-sell-summerfest.txt', '🌟・vip-lounge-4.txt', '🌮・buy-sell-cinco-de-mayo.txt', '🍀・buy-sell-st-patricks.txt', '🍃・buy-sell-equinox.txt', '🍍・buy-sell-pineapple.txt', '🍡・buy-sell-lunar-new-year.txt', '🎂・buy-sell-anniversary.txt', '🎃・buy-sell-halloween.txt', '🎈・buy-sell-balloonwarz.txt', '🏹・buy-sell-assassins.txt', '🐚・buy-sell-beachparty.txt', '🐣・buy-sell-easter.txt', '👽・buy-sell-aliens.txt', '💝・buy-sell-valentines.txt', '🖤・buy-sell-blackfriday.txt', '😇・buy-sell-grow4good.txt', '🛕・buy-sell-ubiweek.txt', '🦃・buy-sell-thanksgiving.txt', '🦅・buy-sell-garuda.txt', '🦓・buy-sell-wildlife.txt', '🧚・buy-sell-wonderweek.txt'], '05_📅・Monthly Events Section': ['❓・buy-sell-locke.txt', '🌟・vip-lounge-5.txt', '🎯・buy-sell-voucher-dayz.txt', '🐉・buy-sell-tournament.txt', '🐺・buy-sell-wolf.txt', '👻・buy-sell-ghost.txt', '💫・buy-sell-comet.txt', '📱・buy-sell-geiger.txt', '🤡・buy-sell-carnival-items.txt', '🦠・buy-sell-mutant-kitchen.txt', '🦴・buy-sell-fossils.txt', '🧟・buy-sell-zombie.txt', '🧭・buy-sell-quests.txt'], '06_🛍️・General Section': ['⚒️・buy-sell-role-drops.txt', '✨・buy-sell-ancestral.txt', '🌈・buy-sell-machine.txt', '🌎・buy-sell-worlds.txt', '🌟・vip-lounge-6.txt', '🍅・buy-sell-consumables.txt', '🎨・buy-sell-paints.txt', '🎹・buy-sell-music.txt', '🏥・buy-sell-packs.txt', '🐉・buy-sell-adventure.txt', '💎・buy-sell-gems.txt', '💣・buy-sell-mines.txt', '💥・buy-sell-blast.txt', '💨・buy-sell-steam.txt', '💼・buy-sell-services.txt', '🔐・buy-sell-locks.txt', '🔮・buy-sell-crystals.txt', '🗻・buy-sell-treasure-map.txt', '🙂・buy-sell-growmoji.txt', '🚔・buy-sell-crime.txt', '🚨・buy-sell-jammers.txt', '🦄・buy-sell-unicorn.txt', '🧙・buy-sell-dungeons.txt', '🧪・buy-sell-science.txt', '🧰・buy-sell-providers.txt', '🧶・buy-sell-silk.txt'], '07_👕・Clothing Section': ['🌟・vip-lounge-7.txt', '🎩・buy-sell-hats.txt', '🎯・buy-sell-petbattle.txt', '🐴・buy-sell-rides.txt', '🐼・buy-sell-face.txt', '👕・buy-sell-shirts.txt', '👖・buy-sell-pants.txt', '👠・buy-sell-shoes.txt', '💈・buy-sell-hair.txt', '🔫・buy-sell-hands.txt', '🦋・buy-sell-back.txt', '🧣・buy-sell-neck.txt', '🧸・buy-sell-pets.txt', '🧿・buy-sell-artifacts.txt'], '08_🎣・Fishing Section': ['🌟・vip-lounge-8.txt', '🎣・buy-sell-rods.txt', '🐟・buy-sell-fish.txt', '📦・buy-sell-fish-items.txt', '🦐・buy-sell-baits.txt', '🦞・buy-sell-lobsters.txt'], '09_🧱・Building Section': ['🌟・vip-lounge-9.txt', '🎢・buy-sell-platform.txt', '🚧・buy-sell-signs.txt', '🚪・buy-sell-doors.txt', '🟪・buy-sell-backgrounds.txt', '🧱・buy-sell-blocks.txt'], '10_🌾・Farming Section': ['🌟・vip-lounge-10.txt', '🌳・buy-sell-farms.txt', '🌾・buy-sell-farmables.txt', '🌿・buy-sell-bountiful.txt', '🔧・buy-sell-farm-tools.txt', '🛒・buy-sell-seeds.txt'], '11_🍳・Cooking Section': ['🌟・vip-lounge-11.txt', '🍯・buy-sell-ingredient.txt', '🥩・buy-sell-food.txt', '🥫・buy-sell-cook-tools.txt'], '12_🏥・Surgery Section': ['🌟・vip-lounge-12.txt', '💉・buy-sell-malady.txt', '💊・buy-sell-surg-tools.txt', '🩺・buy-sell-surg-items.txt'], '13_🪐・Startopia Section': ['🌌・buy-sell-startrek.txt', '🌟・vip-lounge-13.txt', '👾・buy-sell-star-items.txt', '🔋・buy-sell-star-tools.txt', '🚀・buy-sell-starships-blasts.txt', '🛸・buy-sell-sector-ships.txt']}

def pastikan_struktur_pesan(folder="pesan"):
    os.makedirs(folder, exist_ok=True)
    ada_kat = any(os.path.isdir(os.path.join(folder, d)) for d in os.listdir(folder))
    if not ada_kat:
        for kat, files in _STRUKTUR_DEFAULT.items():
            kp = os.path.join(folder, kat)
            os.makedirs(kp, exist_ok=True)
            for fn in files:
                fp = os.path.join(kp, fn)
                if not os.path.exists(fp):
                    open(fp, "w", encoding="utf-8").close()

def get_kategori_list(folder="pesan"):
    pastikan_struktur_pesan(folder)
    dirs = sorted([d for d in os.listdir(folder) if os.path.isdir(os.path.join(folder, d))])
    cfg = load_cfg()
    res = []
    for d in dirs:
        dp = os.path.join(folder, d)
        txts = sorted([f for f in os.listdir(dp) if f.endswith(".txt")])
        siap, isi_cnt, ch_cnt = 0, 0, 0
        for f in txts:
            fp, rel = os.path.join(dp, f), f"{d}/{f}"
            ada_isi = os.path.exists(fp) and os.path.getsize(fp) > 0
            ada_ch = count_chid(cfg, rel) > 0
            if ada_isi: isi_cnt += 1
            if ada_ch: ch_cnt += 1
            if ada_isi and ada_ch: siap += 1
        res.append({"dir": d, "nama": clean_name(d), "total": len(txts), "siap": siap, "isi": isi_cnt, "ch": ch_cnt})
    return res

def tampilkan_menu_kelola_pesan(banner_func=None, folder_pesan="pesan"):
    kat_aktif = None
    iw = 50
    while True:
        from utils import bersihkan_layar; bersihkan_layar()
        if banner_func: banner_func()
        cfg = load_cfg()

        if kat_aktif is None:
            kats = get_kategori_list(folder_pesan)
            print(f"{C_CYAN}╭{'─'*iw}╮{C_RESET}")
            print(f"{C_CYAN}│{C_WHITE}{pad(' 📝 PILIH KATEGORI & SUB-KATEGORI PESAN', iw)}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}├{'─'*iw}┤{C_RESET}")
            leg = f" {C_GREEN}Hijau=Siap{C_RESET} {C_RED}Merah=No ChID{C_RESET} {C_YELLOW}Kuning=Msg Empty{C_RESET}"
            print(f"{C_CYAN}│{pad(leg, iw)}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}├{'─'*iw}┤{C_RESET}")
            for i, k in enumerate(kats, 1):
                if k["total"] == 0: st = f"{C_GRAY}[0/0]{C_RESET} "
                elif k["siap"] > 0: st = f"{C_GREEN}[{k['siap']}/{k['total']} Siap]{C_RESET} "
                elif k["ch"] == 0: st = f"{C_RED}[{k['isi']}/{k['total']} Isi]{C_RESET} "
                else: st = f"{C_YELLOW}[{k['isi']}/{k['total']} Isi]{C_RESET} "
                kiri = f" {C_CYAN}[{i:02d}]{C_RESET} {C_WHITE}{trunc(k['nama'], iw - 7 - vw(st))}{C_RESET}"
                print(f"{C_CYAN}│{C_RESET}{pad(kiri, iw - vw(st))}{st}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}├{'─'*iw}┤{C_RESET}")
            print(f"{C_CYAN}│{pad(f' {C_CYAN}[J]{C_RESET} ⏱️ {C_YELLOW}Atur Waktu Jeda (Semua / Sub-Kategori){C_RESET}', iw)}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}│{pad(f' {C_CYAN}[0]{C_RESET} 🔙 {C_WHITE}Kembali ke Menu Utama{C_RESET}', iw)}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}╰{'─'*iw}╯{C_RESET}")
            p = input(f"\n{C_GREEN}➤ Pilih kategori [0-{len(kats)}], [J], atau: {C_RESET}").strip().lower()
            if p == "0": return "0", None
            if p == "j": return "j_global", kats
            if p.isdigit() and 1 <= int(p) <= len(kats): kat_aktif = kats[int(p)-1]["dir"]
        else:
            dp = os.path.join(folder_pesan, kat_aktif)
            txts = sorted([f for f in os.listdir(dp) if f.endswith(".txt")]) if os.path.exists(dp) else []
            print(f"{C_CYAN}╭{'─'*iw}╮{C_RESET}")
            print(f"{C_CYAN}│{C_WHITE}{pad(f' 📂 {clean_name(kat_aktif)}', iw)}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}├{'─'*iw}┤{C_RESET}")
            if not txts:
                print(f"{C_CYAN}│{pad(f' {C_GRAY}(Belum ada file di kategori ini){C_RESET}', iw)}{C_CYAN}│{C_RESET}")
            for i, f in enumerate(txts, 1):
                fp, rel = os.path.join(dp, f), f"{kat_aktif}/{f}"
                ada_isi = os.path.exists(fp) and os.path.getsize(fp) > 0
                jml_ch = count_chid(cfg, rel)
                t_msg = f"{C_GREEN}[Msg:Ready]{C_RESET}" if ada_isi else f"{C_YELLOW}[Msg:Empty]{C_RESET}"
                t_ch = f"{C_GREEN}[ChID:{jml_ch}]{C_RESET}" if jml_ch > 0 else f"{C_RED}[No ChID]{C_RESET}"
                kanan = f"{t_msg}{t_ch} "
                kiri = f" {C_CYAN}[{i:02d}]{C_RESET} {C_WHITE}{trunc(clean_name(f), iw - 6 - vw(kanan))}{C_RESET}"
                print(f"{C_CYAN}│{C_RESET}{pad(kiri, iw - vw(kanan))}{kanan}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}├{'─'*iw}┤{C_RESET}")
            hw = 25
            m_baris = [
                (f" {C_CYAN}[1]{C_RESET} 📄 {C_GREEN}Buat File Baru{C_RESET}", f"{C_CYAN}[2]{C_RESET} 📝 {C_WHITE}Edit Isi Pesan{C_RESET}"),
                (f" {C_CYAN}[3]{C_RESET} 🧹 {C_YELLOW}Kosongkan Isi{C_RESET}", f"{C_CYAN}[4]{C_RESET} 📢 {C_WHITE}Atur Channel ID{C_RESET}"),
                (f" {C_CYAN}[5]{C_RESET} ⏳ {C_WHITE}Atur Waktu Jeda{C_RESET}", f"{C_CYAN}[6]{C_RESET} ❌ {C_RED}Hapus File{C_RESET}"),
            ]
            for l_col, r_col in m_baris:
                print(f"{C_CYAN}│{C_RESET}{pad(l_col, hw)}{pad(r_col, iw - hw)}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}│{C_RESET}{pad(f' {C_CYAN}[0]{C_RESET} 🔙 {C_WHITE}Kembali ke Daftar Kategori{C_RESET}', iw)}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}╰{'─'*iw}╯{C_RESET}")
            p = input(f"\n{C_GREEN}➤ Pilih menu [0-6]: {C_RESET}").strip()
            if p == "0": kat_aktif = None
            elif p == "1": return "1", kat_aktif
            elif p == "5" and txts:
                return "5_kat", kat_aktif
            elif p in ("2", "3", "4", "6") and txts:
                ns = input(f"{C_CYAN}➤ Pilih nomor file [1-{len(txts)}]: {C_RESET}").strip()
                if ns.isdigit() and 1 <= int(ns) <= len(txts): return p, f"{kat_aktif}/{txts[int(ns)-1]}"
