import time, requests
from colorama import Fore
from utils import tampilkan_progress_kirim

BASE_API = "https://discord.com" + "/api/v9/channels/"
USER_API = "https://discord.com" + "/api/v9/users/@me"

def hapus_pesan_lama(ch_id, cfg, headers):
    try:
        msg_id = cfg["last_message_id"]
        if not msg_id:
            if not cfg["user_id"]:
                r_me = requests.get(USER_API, headers=headers, timeout=15)
                if r_me.status_code == 200:
                    cfg["user_id"] = r_me.json().get("id")
            if cfg["user_id"]:
                r_msgs = requests.get(f"{BASE_API}{ch_id}/messages?limit=15", headers=headers, timeout=15)
                if r_msgs.status_code == 200:
                    msg_id = next((m["id"] for m in r_msgs.json() if m.get("author", {}).get("id") == cfg["user_id"]), None)
        if msg_id:
            r_del = requests.delete(f"{BASE_API}{ch_id}/messages/{msg_id}", headers=headers, timeout=15)
            if r_del.status_code in (200, 204):
                cfg["last_message_id"] = None
    except Exception:
        pass

def cek_slowmode_channel(ch_id, headers):
    try:
        r = requests.get(f"{BASE_API}{ch_id}", headers=headers, timeout=10)
        if r.status_code == 200:
            return int(r.json().get("rate_limit_per_user", 0))
    except Exception:
        pass
    return 0

def verifikasi_pesan_terkirim(ch_id, msg_id, headers):
    if not msg_id:
        return False, "ID pesan kosong"
    for langkah in range(3):
        tampilkan_progress_kirim(70 + (langkah * 8), f"Verifikasi server ({langkah + 1}/3)...", Fore.YELLOW)
        time.sleep(1)
    for _ in range(2):
        try:
            r_cek = requests.get(f"{BASE_API}{ch_id}/messages?limit=10", headers=headers, timeout=15)
            if r_cek.status_code == 200:
                for m in r_cek.json():
                    if m.get("id") == msg_id:
                        return True, "Terverifikasi muncul di channel"
                return False, "Terhapus AutoMod/Bot server"
            elif r_cek.status_code == 429:
                time.sleep(min(float(r_cek.json().get("retry_after", 3)) + 1, 6))
            else:
                return False, f"HTTP {r_cek.status_code}"
        except Exception as e:
            return False, f"Error cek: {e}"
    return False, "Timeout verifikasi"
