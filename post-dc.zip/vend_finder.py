from ui_input import input_menyatu as input_frame_vf, reset_frame_input
from ui_input import input_menyatu as input_frame_vf, reset_frame_input
from ui_input import input_menyatu, reset_frame_input
import sys
from colorama import Fore
import re
import gc, json, os, re, time, unicodedata, urllib.parse, requests
from datetime import datetime, timezone, timedelta
from colorama import Fore, init
from utils import bersihkan_layar as _cls, tampilkan_banner

init(autoreset=True)
POST_DC_DIR = "."
CONFIG_PATH = os.path.join(POST_DC_DIR, "config.json")
TOKEN_PATH = os.path.join(POST_DC_DIR, "token.txt")
PESAN_DIR = os.path.join(POST_DC_DIR, "pesan")
API_V9 = "https://discord.com" + "/api/v9"
IW = 50
HARI_SCAN = 7

C_RESET, C_CYAN, C_GREEN = "\033[0m", "\033[96m", "\033[92m"
C_YELLOW, C_RED, C_WHITE, C_GRAY = "\033[93m", "\033[91m", "\033[97m", "\033[90m"


def _lebar_teks_bersih_vf(s):
    import unicodedata
    bersih = re.sub(r'\033\[[0-9;]*[mGK]', '', s)
    w = 0
    for ch in bersih:
        if unicodedata.combining(ch) or ch == '\ufe0f':
            continue
        w += 2 if unicodedata.east_asian_width(ch) in ('W', 'F') else 1
    return w


def _hapus_vf(prompt=""):
    bersih_prompt = prompt.lstrip("\n")
    awal_nl = "\n" if prompt.startswith("\n") else ""
    kolom_kursor = 3 + _lebar_teks_bersih_vf(bersih_prompt)
    sys.stdout.write(
        f"{awal_nl}{Fore.CYAN}╔══════════════════════════════════════════════════╗\n"
        f"{Fore.CYAN}║ {bersih_prompt}\033[52G{Fore.CYAN}║\n"
        f"{Fore.CYAN}╚══════════════════════════════════════════════════╝\033[1A\033[{kolom_kursor}G"
    )
    sys.stdout.flush()
    hasil = input()
    sys.stdout.write("\n")
    sys.stdout.flush()
    return hasil


def bersihkan_layar(): _cls(); tampilkan_banner()

def vw(t):
    c = re.sub(r'\033\[[0-9;]*m', '', t)
    return sum(0 if (unicodedata.combining(x) or x == '\ufe0f') else (2 if unicodedata.east_asian_width(x) in ('W', 'F') else 1) for x in c)

def pad(t, w): return t + (" " * max(0, w - vw(t)))

def trunc(t, mw):
    if vw(t) <= mw: return t
    o, w = "", 0
    for x in t:
        if unicodedata.combining(x) or x == '\ufe0f': o += x; continue
        cw = 2 if unicodedata.east_asian_width(x) in ('W', 'F') else 1
        if w + cw > mw: return o
        o += x; w += cw
    return o

def clean_name(s): return re.sub(r'^\d+[_\-\s]*', '', os.path.splitext(s)[0]).strip()

def bersihkan_teks_dc(teks):
    t = unicodedata.normalize("NFKC", teks).replace("\r", "").replace("\ufe0f", "")
    _map_emoji_huruf = {}
    for _i in range(26):
        _map_emoji_huruf[0x1F170 + _i] = chr(65 + _i)
        _map_emoji_huruf[0x1F1E6 + _i] = chr(65 + _i)
    t = t.translate(_map_emoji_huruf)
    t = re.sub(r'<a?:(bgls?|dls?|wls?):\d+>', r' \1 ', t, flags=re.IGNORECASE)
    t = re.sub(r':(bgls?|dls?|wls?):', r' \1 ', t, flags=re.IGNORECASE)
    t = re.sub(r'<a?:[a-zA-Z0-9_]+:\d+>', ' ', t)
    t = re.sub(r'[*_~`>|\u200b-\u200f\ufeff]', '', t)
    return "".join(ch for ch in t if ch == "\n" or ord(ch) >= 32)

def load_cfg():
    try: return json.load(open(CONFIG_PATH, encoding="utf-8"))
    except Exception: return {"channels": {}}

def load_tokens():
    if not os.path.exists(TOKEN_PATH): return []
    return [l.strip() for l in open(TOKEN_PATH, encoding="utf-8") if l.strip()]

def get_headers(tokens, token_ke=1):
    idx = max(0, min(int(token_ke) - 1, len(tokens) - 1))
    return {"Authorization": tokens[idx], "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

def get_kategori_list():
    if not os.path.exists(PESAN_DIR): return []
    dirs = sorted([d for d in os.listdir(PESAN_DIR) if os.path.isdir(os.path.join(PESAN_DIR, d))])
    chs = load_cfg().get("channels", {})
    return [{"dir": d, "nama": clean_name(d), "ch": sum(1 for v in chs.values() if v.get("file", "").startswith(f"{d}/"))} for d in dirs]

def buat_min_snowflake(hari_scan=7):
    batas = datetime.now(timezone.utc) - timedelta(days=hari_scan)
    ms_discord = int(batas.timestamp() * 1000) - 1420070400000
    return str(max(0, ms_discord) << 22)

def deteksi_guild_ids(targets, tokens):
    guild_map = {}
    dicek = set()
    for cid, inf in targets:
        tk = inf.get("token_ke", 1)
        if tk in dicek:
            continue
        try:
            r = requests.get(f"{API_V9}/channels/{cid}", headers=get_headers(tokens, tk), timeout=10)
            if r.status_code == 200:
                gid = r.json().get("guild_id")
                if gid:
                    guild_map[gid] = tk
                    dicek.add(tk)
        except Exception:
            pass
        if len(guild_map) >= len(tokens):
            break
    return guild_map

def stream_search_guild(guild_id, keyword, headers, max_hal=3):
    q_enc = urllib.parse.quote(keyword)
    for hal in range(max_hal):
        offset = hal * 25
        _teks_hal = f" └─ Memindai Halaman {hal + 1}/{max_hal} ({(hal + 1)*25} pesan)..."
        sys.stdout.write(f"\033[1A\r{C_CYAN}│{C_RESET}{C_GRAY}{pad(_teks_hal, IW)}{C_RESET}{C_CYAN}│{C_RESET}\n{C_CYAN}╰{'─'*IW}╯{C_RESET}")
        sys.stdout.flush()
        url = f"{API_V9}/guilds/{guild_id}/messages/search?content={q_enc}&offset={offset}"
        sukses = False
        for _ in range(3):
            try:
                r = requests.get(url, headers=headers, timeout=12)
                if r.status_code == 200:
                    data = r.json()
                    total_res = data.get("total_results", 0)
                    blok_msgs = data.get("messages", [])
                    if not blok_msgs:
                        del r, data
                        gc.collect()
                        print("")
                        return
                    batch = []
                    for grup in blok_msgs:
                        for m in grup:
                            if m.get("hit"):
                                batch.append({
                                    "id": m.get("id"),
                                    "channel_id": m.get("channel_id"),
                                    "content": m.get("content", ""),
                                    "timestamp": m.get("timestamp", ""),
                                    "author": {"username": m.get("author", {}).get("username", "?")}
                                })
                    habis = len(blok_msgs) < 25 or (offset + 25) >= total_res
                    del r, data, blok_msgs
                    gc.collect()
                    yield batch
                    if habis:
                        print("")
                        return
                    sukses = True
                    break
                elif r.status_code in (202, 429):
                    ra = float(r.json().get("retry_after", 2))
                    del r
                    time.sleep(min(ra + 0.4, 5))
                else:
                    print(f"\n{C_RED}[!] HTTP {r.status_code}{C_RESET}")
                    return
            except Exception as e:
                print(f"\n{C_RED}[!] Error: {e}{C_RESET}")
                return
        if not sukses:
            break
        time.sleep(0.3)
    print("")

def _cari_pola_world(sumber, bl):
    pola_list = [
        r'(?:^|[\s•►▸»|/,(])(?:at+|di|in|go+\s+to+|go+t?o*|remember)(?:\s+|[:=@]+\s*)(?:[^\w\s]\s*)*(?:(?:wls?|dls?|bgls?)\s+)*([a-zA-Z0-9]{2,24})\b',
        r'(?:^|\s)@\s*([a-zA-Z0-9]{2,24})\b',
        r'[▶►▸»➤➡👉🚪🌍🌎🌏📍]\s*([A-Z0-9]{2,24})\b',
        r'(?:^|[\s•►▸»|/,(])(?:(?:vend|vending)(?:\s+world)?|world)(?:\s+|[:=@]+\s*)(?:[^\w\s]\s*)*([a-zA-Z0-9]{2,24})\b',
    ]
    for pola in pola_list:
        for m in re.finditer(pola, sumber, re.IGNORECASE):
            k = m.group(1).upper()
            sisa_teks = sumber[m.end():m.end()+8].lower()
            if k.isdigit() and re.match(r'^\s*(?:bgls?|dls?|wls?|each|ea)\b', sisa_teks):
                continue
            if k.lower() not in bl and not re.fullmatch(r"\d+letters?", k, re.IGNORECASE):
                return k
    return None

def ekstrak_world(teks_bersih, baris_target, kw_words=None):
    bl = {
        "wl", "wls", "dl", "dls", "bgl", "bgls", "each", "ea", "rate",
        "stock", "stok", "discord", "dm", "pm", "here", "vend", "vending",
        "seed", "seeds", "block", "blocks", "item", "items", "cheap", "sell",
        "selling", "buy", "buying", "wts", "wtb", "sold", "out", "restock",
        "fast", "pure", "open", "close", "closed", "offer", "offers", "nego",
        "firm", "world", "link", "msg", "message", "me", "not", "go", "goto",
        "at", "di", "in", "to", "anywhere", "all", "ride", "rides", "hand",
        "hands", "shop", "store", "price", "real", "new", "update", "if",
        "for", "with", "and", "or", "pls", "please", "ty", "thx", "online", "offline", "the", "a", "an", "my", "this", "that", "our", "your", "any", "some", "etc", "sale", "range", "name", "names", "letter", "letters", "arabic", "english", "glitch", "rare", "info", "more", "many", "super", "owner", "blingin", "chain", "crown", "cape", "wings", "wing", "ring", "sword", "staff", "mask", "hat", "hats", "shirt", "shirts", "pants", "shoes", "eyes", "eye", "hair"
    }
    if kw_words:
        bl.update(w.lower() for w in kw_words)

    # 1. Prioritas utama: pola lokasi eksplisit di segmen item maupun seluruh pesan
    w = _cari_pola_world(baris_target, bl) or _cari_pola_world(teks_bersih, bl)
    if w:
        return w

    # 2. Fallback: baris berdiri sendiri di pesan asli (bukan segmen potongan koma)
    for baris in teks_bersih.splitlines():
        kandidat = re.sub(r'^[^\w]+|[^\w]+$', '', baris.strip())
        if re.fullmatch(r'[a-zA-Z0-9]{2,24}', kandidat) and not kandidat.isdigit():
            if kandidat.lower() not in bl:
                return kandidat.upper()

    # 3. Fallback akhir baris judul promo (misal: "SELL ANY BLOCK IZPAR" / "SELL CHEAP SEED NAMA")
    for baris in teks_bersih.splitlines():
        m_end = re.search(
            r'\b(?:any\s+)?(?:blocks?|seeds?|items?|packs?|cheap|here)\s+([A-Z0-9]{2,24})(?:\s+(?:no\s*link|nolink|fast|cheap))?\s*$',
            baris.strip(),
            re.IGNORECASE
        )
        if m_end:
            k = m_end.group(1).upper()
            if not k.isdigit() and k.lower() not in bl:
                return k
    return "DM"

def format_harga_wl(wl, polos=False):
    if wl is None:
        return "Cek Pesan"
    if wl >= 10000:
        bgl = int(wl // 10000)
        sisa_dl = (wl % 10000) / 100
        return f"{bgl} BGL {sisa_dl:g} DL" if sisa_dl > 0 else f"{bgl} BGL"
    if wl >= 100:
        return f"{wl / 100:g} DL"
    return f"{wl:g} WL"

def _cari_harga_di_segmen(segmen, kw_words):
    m = re.search(r'(\d+(?:[.,]\d+)?)[\s:\-]*(bgls?|dls?|wls?)\b', segmen, re.IGNORECASE)
    if m:
        val = float(m.group(1).replace(",", "."))
        s = m.group(2).lower()
        unit = "bgl" if s.startswith("bgl") else ("dl" if s.startswith("dl") else "wl")
        mult = 10000 if unit == "bgl" else (100 if unit == "dl" else 1)
        return val * mult, False, unit
    mr = re.search(r'\b(\d+)\s*/\s*(1|wl)\b', segmen, re.IGNORECASE)
    if mr and float(mr.group(1)) > 0:
        return round(1.0 / float(mr.group(1)), 3), False, "wl"
    s_tanpa_kw = segmen.lower()
    for w in kw_words:
        s_tanpa_kw = s_tanpa_kw.replace(w, " ")
    m_polos = re.search(r'(?:^|\s|:|=|-|@)\s*(\d+(?:[.,]\d+)?)\s*(?!\s*letters?\b)(?:$|\s|each|ea)', s_tanpa_kw)
    if m_polos:
        try:
            val = float(m_polos.group(1).replace(",", "."))
            if 1 <= val <= 500000:
                return val, True, None
        except ValueError:
            pass
    return None, False, None

def ekstrak_harga_wl(teks_bersih, segmen_target, kw_words=None):
    kw_words = kw_words or []
    if segmen_target:
        h, polos, unit = _cari_harga_di_segmen(segmen_target, kw_words)
        if h is not None:
            return h, polos, unit
    return None, False, None

def format_waktu_relatif(ts_str):
    try:
        detik = int((datetime.now(timezone.utc) - datetime.fromisoformat(ts_str)).total_seconds())
        if detik < 60: return f"{detik} detik lalu"
        if detik < 3600: return f"{detik // 60} menit lalu"
        if detik < 86400: return f"{detik // 3600} jam lalu"
        return f"{detik // 86400} hari lalu"
    except Exception: return "-"

def bungkus_teks_kotak(teks, lebar_maks):
    res = []
    for p in teks.splitlines():
        p = p.strip()
        if not p: res.append(""); continue
        b = ""
        for k in p.split(" "):
            if vw(k) > lebar_maks:
                if b: res.append(b); b = ""
                while vw(k) > lebar_maks: pt = trunc(k, lebar_maks); res.append(pt); k = k[len(pt):]
                b = k
            elif not b: b = k
            elif vw(b + " " + k) <= lebar_maks: b += " " + k
            else: res.append(b); b = k
        if b: res.append(b)
    return res

def pilih_target():
    kat = None
    while True:
        bersihkan_layar(); reset_frame_input()
        chs = load_cfg().get("channels", {})
        if kat is None:
            kats = get_kategori_list()
            print(f"{C_CYAN}╭{'─'*IW}╮\n│{C_YELLOW}{pad(' ⚡ VEND FINDER (FAST SEARCH)', IW)}{C_RESET}{C_CYAN}│\n├{'─'*IW}┤{C_RESET}")
            for i, k in enumerate(kats, 1):
                st = f"{C_GREEN}[{k['ch']} ChID]{C_RESET} " if k["ch"] > 0 else f"{C_RED}[0 ChID]{C_RESET} "
                nm = trunc(k["nama"], IW - 7 - vw(st))
                print(f"{C_CYAN}│{C_RESET}{pad(f' {C_CYAN}[{i:02d}]{C_RESET} {C_WHITE}{nm}{C_RESET}', IW - vw(st))}{st}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}├{'─'*IW}┤\n│{pad(f' {C_CYAN}[A]{C_RESET} 🌐 {C_YELLOW}Cari Semua Kategori (Global Cepat){C_RESET}', IW)}{C_CYAN}│")
            print(f"│{pad(f' {C_RED}[0]{C_RESET} ❌ {C_WHITE}Keluar{C_RESET}', IW)}{C_CYAN}│\n╰{'─'*IW}╯{C_RESET}")
            p = input_frame_vf(f"\n{C_GREEN}➤ Pilih kategori [0-{len(kats)}] atau [A]: {C_RESET}").strip().lower()
            if p == "0": return None, None
            if p == "a": return "Semua Kategori (Global)", [(c, i) for c, i in chs.items() if i.get("file")]
            if p.isdigit() and 1 <= int(p) <= len(kats): kat = kats[int(p) - 1]["dir"]
        else:
            dp = os.path.join(PESAN_DIR, kat)
            txts = sorted([f for f in os.listdir(dp) if f.endswith(".txt")]) if os.path.exists(dp) else []
            print(f"{C_CYAN}╭{'─'*IW}╮\n│{C_WHITE}{pad(f' 📂 {clean_name(kat)}', IW)}{C_CYAN}│\n├{'─'*IW}┤{C_RESET}")
            for i, f in enumerate(txts, 1):
                rel = f"{kat}/{f}"
                jc = sum(1 for v in chs.values() if v.get("file") == rel)
                st = f"{C_GREEN}[{jc} Ch]{C_RESET} " if jc > 0 else f"{C_RED}[0 Ch]{C_RESET} "
                nm = trunc(clean_name(f), IW - 7 - vw(st))
                print(f"{C_CYAN}│{C_RESET}{pad(f' {C_CYAN}[{i:02d}]{C_RESET} {C_WHITE}{nm}{C_RESET}', IW - vw(st))}{st}{C_CYAN}│{C_RESET}")
            print(f"{C_CYAN}├{'─'*IW}┤\n│{pad(f' {C_CYAN}[A]{C_RESET} 🌐 {C_YELLOW}Scan Semua Sub-Kategori{C_RESET}', IW)}{C_CYAN}│")
            print(f"│{pad(f' {C_CYAN}[0]{C_RESET} 🔙 {C_WHITE}Kembali ke Daftar Kategori{C_RESET}', IW)}{C_CYAN}│\n╰{'─'*IW}╯{C_RESET}")
            p = input_frame_vf(f"\n{C_GREEN}➤ Pilih [1-{len(txts)}], [A], atau: {C_RESET}").strip().lower()
            if p == "0": kat = None
            elif p == "a": return clean_name(kat) + " (Semua)", [(c, i) for c, i in chs.items() if i.get("file", "").startswith(f"{kat}/")]
            elif p.isdigit() and 1 <= int(p) <= len(txts):
                rel = f"{kat}/{txts[int(p) - 1]}"
                return clean_name(txts[int(p) - 1]), [(c, i) for c, i in chs.items() if i.get("file") == rel]

def inferensi_satuan_otomatis(hasil_list):
    import math, statistics

    sampel_wl = [
        it["raw_val"] for it in hasil_list
        if not it.get("is_polos")
        and it.get("raw_val") is not None
        and it["raw_val"] > 0
        and "service" not in it.get("sub", "").lower()
        and "customer" not in it.get("snippet", "").lower()
    ]
    if not sampel_wl:
        sampel_wl = [
            it["raw_val"] for it in hasil_list
            if not it.get("is_polos") and it.get("raw_val") is not None and it["raw_val"] > 0
        ]
    median_wl = statistics.median(sampel_wl) if sampel_wl else None

    ada_skala_dl = any(
        it.get("is_polos") and it.get("raw_val") is not None and 100 <= it["raw_val"] <= 999
        for it in hasil_list
    )

    for it in hasil_list:
        if it.get("is_polos") and it.get("raw_val") is not None and it["raw_val"] > 0:
            v = it["raw_val"]
            if median_wl is not None:
                kandidat = [
                    (v, abs(math.log10(v / median_wl))),
                    (v * 100, abs(math.log10((v * 100) / median_wl))),
                    (v * 10000, abs(math.log10((v * 10000) / median_wl))),
                ]
                wl_final, log_jarak = min(kandidat, key=lambda x: x[1])
                if log_jarak > 1.0:
                    wl_final = (v * 100) if (100 <= v <= 999 or (ada_skala_dl and 2 <= v <= 99)) else v
            else:
                wl_final = (v * 100) if (100 <= v <= 999 or (ada_skala_dl and 2 <= v <= 99)) else v

            it["wl"] = wl_final
            it["hrg"] = format_harga_wl(wl_final, polos=False)
    return hasil_list

def menu_vend_finder():
    reset_frame_input()
    tokens = load_tokens()
    if not tokens: print(Fore.RED + "[!] Token kosong!"); return
    while True:
        nama, targets = pilih_target()
        if nama is None: break
        if not targets: input_frame_vf(Fore.RED + "\n[!] Belum ada Channel ID. Enter..."); continue
        kw = input_frame_vf(f"\n{C_CYAN}➤ Nama item (cth: Royal Red Panda Spirit): {C_RESET}").strip()
        if not kw: continue
        h_in = input_frame_vf(f"{C_CYAN}➤ Jumlah halaman cek (1-40, Enter = 3 hal): {C_RESET}").strip()
        if "-" in h_in and h_in.split("-")[-1].strip().isdigit():
            h_in = h_in.split("-")[-1].strip()
        hal_pilih = int(h_in) if (h_in.isdigit() and 1 <= int(h_in) <= 40) else 3
        bersihkan_layar(); reset_frame_input()
        import textwrap as _tw
        _judul_cari = f"⚡ Mencari '{kw}' via Fast Search (Maks {hal_pilih} Hal)..."
        _baris_cari = _tw.wrap(_judul_cari, width=48, subsequent_indent="   ") or [_judul_cari]
        print(f"{C_CYAN}╭{'─'*IW}╮{C_RESET}")
        for _bc in _baris_cari:
            print(f"{C_CYAN}│{C_RESET}{C_YELLOW}{pad(' ' + _bc, IW)}{C_RESET}{C_CYAN}│{C_RESET}")
        print(f"{C_CYAN}├{'─'*IW}┤{C_RESET}")
        print(f"{C_CYAN}│{C_RESET}{C_GRAY}{pad(' └─ Menyiapkan pencarian...', IW)}{C_RESET}{C_CYAN}│{C_RESET}")
        print(f"{C_CYAN}╰{'─'*IW}╯{C_RESET}", end="", flush=True)
        target_map, all_chs = dict(targets), load_cfg().get("channels", {})
        guild_map = deteksi_guild_ids(targets, tokens)
        if not guild_map: input_frame_vf(Fore.RED + "[!] Gagal deteksi server. Enter..."); continue
        hasil, seen, kw_words = [], set(), kw.lower().split()
        for gid, tk in guild_map.items():
            for batch in stream_search_guild(gid, kw, get_headers(tokens, tk), max_hal=hal_pilih):
                for m in batch:
                    mid, cid = m.get("id"), str(m.get("channel_id", ""))
                    if mid in seen or (nama != "Semua Kategori (Global)" and cid not in target_map): continue
                    seen.add(mid)
                    file_rel = all_chs.get(cid, {}).get("file", "")
                    if "/" in file_rel:
                        p_kat, p_sub = file_rel.split("/", 1)
                        kat_nama, sub_nama = clean_name(p_kat), clean_name(p_sub)
                    else:
                        kat_nama, sub_nama = "Lainnya", f"Ch-{cid[-4:]}"
                    kt_raw = m.get("content", "").strip()
                    if not kt_raw: continue
                    kt = bersihkan_teks_dc(kt_raw)
                    kl = kt.lower()
                    if not all(k in kl for k in kw_words): continue
                    segmen_semua = [
                        s.strip() for s in re.split(r'[\n,;|]+|/(?!\s*(?:\d+|wls?|dls?|bgls?)\b)', kt, flags=re.IGNORECASE)
                        if s.strip()
                    ]
                    pola_beli = r'(?:^[\s\W_]*(?:also\s+|and\s+)?(?:f?wtb|f?buying|f?buy|lf)\b|\b(?:also\s+buy|wtb)\b)'
                    segmen_jual = [s for s in segmen_semua if not re.search(pola_beli, s, re.IGNORECASE)]
                    baris_cocok = [s for s in segmen_jual if all(k in s.lower() for k in kw_words)]
                    if not baris_cocok:
                        continue
                    baris_item = next(iter(baris_cocok), "")
                    kw_pertama = next(iter(kw_words), "")
                    if baris_item and kw_pertama:
                        pos_kw = baris_item.lower().find(kw_pertama)
                        if pos_kw > 0:
                            baris_item = baris_item[pos_kw:].strip()
                    wl, is_polos, unit_eks = ekstrak_harga_wl(kt, baris_item, kw_words)
                    sort_val = (wl * 100 if is_polos else wl) if wl is not None else float("inf"); hasil.append({"wl": sort_val, "raw_val": wl, "is_polos": is_polos, "unit": unit_eks, "hrg": format_harga_wl(wl, is_polos), "wld": ("DM" if ("world" in sub_nama.lower() and re.search(r"(?:\b(?:dm|msg|pm)\s+me\b|\bdm\s*$)", kl, re.MULTILINE)) else ("List World" if ("world" in sub_nama.lower() and not re.search(r"\b(?:at+|di|in|go+\s+to+|go+t?o*|@)\b", kl)) else ekstrak_world(kt, baris_item, kw_words))), "usr": m.get("author", {}).get("username", "?"), "kat": kat_nama, "sub": sub_nama, "snippet": re.sub(r"\s+", " ", baris_item or kt), "kt": kt_raw, "ts": m.get("timestamp", "")})
        gc.collect()
        hasil = inferensi_satuan_otomatis(hasil)
        hasil.sort(key=lambda x: x["wl"])
        # Deduplikasi iklan spam dari penjual + world + cuplikan yang sama
        hasil_unik, seen_spam = [], set()
        for it in hasil:
            is_royal = "royal" in it["snippet"].lower(); kunci_spam = (it["usr"].lower(), it["wld"].lower(), is_royal) if it["wld"] != "DM" else (it["usr"].lower(), it["snippet"][:30].lower())
            if kunci_spam in seen_spam:
                continue
            seen_spam.add(kunci_spam)
            hasil_unik.append(it)
        hasil = hasil_unik

        hal_skrg = 0
        per_hal = max(1, len(hasil))
        while True:
            bersihkan_layar(); reset_frame_input()
            total_hal = max(1, (len(hasil) + per_hal - 1) // per_hal)
            hal_skrg = max(0, min(hal_skrg, total_hal - 1))
            mulai = hal_skrg * per_hal
            akhir = min(mulai + per_hal, len(hasil))
            maks = hasil[mulai:akhir]

            print(f"{C_CYAN}╭{'─'*IW}╮\n│{C_YELLOW}{pad(f' ⚡ HASIL ({hal_pilih} HAL): {trunc(kw, 16)} ({len(hasil)} | H.{hal_skrg+1}/{total_hal})', IW)}{C_RESET}{C_CYAN}│\n├{'─'*IW}┤{C_RESET}")
            if not hasil:
                print(f"{C_CYAN}│{C_RED}{pad(f' Tidak ditemukan dalam {hal_pilih} halaman terakhir.', IW)}{C_RESET}{C_CYAN}│\n╰{'─'*IW}╯{C_RESET}")
                input_frame_vf("\nEnter..."); break

            for idx_lokal, it in enumerate(maks):
                no_urut = mulai + idx_lokal + 1
                hc = C_GREEN if it["wl"] != float("inf") else C_GRAY
                print(f"{C_CYAN}│{pad(f' {C_CYAN}[{no_urut:02d}]{C_RESET} {hc}{pad(it["hrg"], 10)}{C_RESET} │ World: {C_YELLOW}{trunc(f"DM : @{it['usr']}" if it["wld"] == "DM" else it["wld"], 16)}{C_RESET}', IW)}{C_CYAN}│{C_RESET}")
                print(f"{C_CYAN}│{pad(f'      {C_CYAN}📂 {trunc(it["kat"], 18)} > #{trunc(it["sub"], 18)}{C_RESET}', IW)}{C_CYAN}│{C_RESET}")
                print(f"{C_CYAN}│{pad(f'      {C_GRAY}└─ {trunc(it["snippet"], IW - 9)}{C_RESET}', IW)}{C_CYAN}│{C_RESET}")
                if idx_lokal < len(maks) - 1:
                    print(f"{C_CYAN}├{'·'*IW}┤{C_RESET}")

            print(f"{C_CYAN}├{'─'*IW}┤")
            nav_str = f" {C_CYAN}[{mulai+1}-{akhir}]{C_RESET} Detail"
            if hal_skrg > 0:
                nav_str += f"  {C_YELLOW}[P]{C_RESET} Prev"
            if hal_skrg < total_hal - 1:
                nav_str += f"  {C_YELLOW}[N]{C_RESET} Next"
            nav_str += f"  {C_RED}[0]{C_RESET} Cari Lagi"
            print(f"│{pad(nav_str, IW)}{C_CYAN}│\n╰{'─'*IW}╯{C_RESET}")

            op = input_frame_vf(f"\n{C_GREEN}➤ Pilih nomor [{mulai+1}-{akhir}] atau untuk cari lagi: {C_RESET}").strip().lower()
            if op == "0" or not op:
                break
            if op == "n" and hal_skrg < total_hal - 1:
                hal_skrg += 1
                continue
            if op == "p" and hal_skrg > 0:
                hal_skrg -= 1
                continue
            if op.isdigit() and (mulai + 1) <= int(op) <= akhir:
                pl = hasil[int(op) - 1]
                bersihkan_layar(); reset_frame_input()
                hc = C_GREEN if pl["wl"] != float("inf") else C_GRAY
                w_rel = format_waktu_relatif(pl.get("ts", ""))
                print(f"{C_CYAN}╭{'─'*IW}╮\n│{C_YELLOW}{pad(f' DETAIL PESAN #{int(op):02d}', IW)}{C_RESET}{C_CYAN}│\n├{'─'*IW}┤{C_RESET}")
                print(f"{C_CYAN}│{pad(f' Harga    : {hc}{pl["hrg"]}{C_RESET}', IW)}{C_CYAN}│{C_RESET}")
                print(f"{C_CYAN}│{pad(f' World    : {C_YELLOW}{trunc(f"DM : @{pl['usr']}" if pl["wld"] == "DM" else pl["wld"], 35)}{C_RESET}', IW)}{C_CYAN}│{C_RESET}")
                print(f"{C_CYAN}│{pad(f' Kategori : {C_WHITE}{trunc(pl["kat"], 35)}{C_RESET}', IW)}{C_CYAN}│{C_RESET}")
                print(f"{C_CYAN}│{pad(f' Channel  : {C_CYAN}#{trunc(pl["sub"], 34)}{C_RESET}', IW)}{C_CYAN}│{C_RESET}")
                print(f"{C_CYAN}│{pad(f' Penjual  : {C_WHITE}{trunc(pl["usr"], 35)}{C_RESET}', IW)}{C_CYAN}│{C_RESET}")
                print(f"{C_CYAN}│{pad(f' Waktu    : {C_GRAY}{w_rel}{C_RESET}', IW)}{C_CYAN}│{C_RESET}")
                print(f"{C_CYAN}├{'─'*IW}┤\n│{C_YELLOW}{pad(' ISI PESAN:', IW)}{C_RESET}{C_CYAN}│\n├{'·'*IW}┤{C_RESET}")
                for b_txt in bungkus_teks_kotak(bersihkan_teks_dc(pl["kt"]), IW - 2):
                    wb = C_GREEN if (any(w in b_txt.lower() for w in kw_words) and b_txt.strip()) else C_WHITE
                    print(f"{C_CYAN}│ {wb}{trunc(b_txt, IW - 2)}{C_RESET}\033[{IW + 2}G{C_CYAN}│{C_RESET}")
                print(f"{C_CYAN}╰{'─'*IW}╯{C_RESET}")
                input_frame_vf(f"\n{C_YELLOW}Tekan Enter untuk kembali...{C_RESET}")

if __name__ == "__main__": menu_vend_finder()

if __name__ == "__main__":
    menu_vend_finder()
