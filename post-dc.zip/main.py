from main_app import *
if __name__ == '__main__':
    mulai_aplikasi()
