# 🚀 PETONG AUTO-POST DISCORD (MULTI-TOKEN EDITION)

Panduan singkat instalasi dan penggunaan untuk pengguna baru di **Termux Android**.

---

## 1. Syarat & Instalasi Awal (Wajib 1x Saat Baru Instal Termux)
> ⚠️ **Penting:** Gunakan aplikasi **Termux versi F-Droid atau GitHub** (jangan dari Google Play Store).

Buka Termux, lalu salin dan tempelkan **1 perintah lengkap** di bawah ini:

```bash
pkg update -y && pkg upgrade -y && pkg install -y python curl unzip termux-api && pip install requests colorama && termux-setup-storage
```
*(Jika muncul pop-up izin akses penyimpanan di layar HP, klik **Izinkan / Allow**).*

---

## 2. Pengaturan Baterai HP (Agar Berjalan 24 Jam di Latar Belakang)
1. Buka **Pengaturan HP -> Aplikasi -> Termux -> Baterai -> pilih "Tidak dibatasi" (*Unrestricted*)**.
2. Buka menu *Recent Apps* (aplikasi terbaru), lalu **Kunci (*Lock*)** jendela Termux agar tidak tertutup otomatis saat layar mati.

---

## 3. Cara Menjalankan Aplikasi
1. Masuk ke folder aplikasi dan jalankan program:
   ```bash
   cd ~/post-dc && python main.py
   ```
2. Salin **Device ID** (`DC-XXXX-XXXX-XXXX`) yang tampil di layar dan kirimkan ke **Admin** untuk mendapatkan **Token Lisensi**.
3. Tempelkan Token Lisensi yang diberikan Admin untuk membuka seluruh menu utama:
   - **Menu ``**: Masukkan Token Akun Discord & atur pemetaan Channel ID.
   - **Menu ``**: Isi teks promosi di dalam file `.txt` kategori yang diinginkan & atur waktu jeda (*cooldown*).
   - **Menu ``**: Atur jeda pengiriman antar *channel* (disarankan minimal `30d` agar aman).
   - **Menu ``**: Jalankan Auto-Post otomatis.
