import io, json, os, sys, time, zipfile
import requests
from colorama import Fore

URL_VERSION = "https://raw.githubusercontent.com/Jayzer-Cyber/Auto-Post-Chanel-DC/main/version.json"
FILE_VERSI_LOKAL = ".versi.json"

def baca_versi_lokal():
    if os.path.exists(FILE_VERSI_LOKAL):
        try:
            with open(FILE_VERSI_LOKAL, "r", encoding="utf-8") as f:
                return json.load(f).get("versi", "1.0.0")
        except Exception:
            pass
    return "1.0.0"

def parse_versi(v_str):
    try:
        return tuple(int(x) for x in str(v_str).strip().split("."))
    except Exception:
        return (1, 0, 0)

def unduh_dengan_progres(url):
    with requests.get(url, stream=True, timeout=(5, 10)) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length", 0))
        buf = io.BytesIO()
        diunduh = 0
        for chunk in r.iter_content(chunk_size=16384):
            if chunk:
                buf.write(chunk)
                diunduh += len(chunk)
                if total > 0:
                    persen = int((diunduh / total) * 100)
                    print(Fore.CYAN + f"\r [1/3] Mengunduh pembaruan... {persen}% ({diunduh // 1024} KB / {total // 1024} KB)   ", end="", flush=True)
                else:
                    print(Fore.CYAN + f"\r [1/3] Mengunduh pembaruan... {diunduh // 1024} KB   ", end="", flush=True)
        print()
        return buf.getvalue()

def cek_dan_jalankan_update():
    versi_lokal = baca_versi_lokal()
    try:
        r = requests.get(f"{URL_VERSION}?t={int(time.time())}", timeout=(4, 6))
        if r.status_code != 200:
            return
        data_remote = r.json()
    except Exception:
        return

    if data_remote.get("maintenance", False):
        os.system("clear")
        print(Fore.YELLOW + "╔══════════════════════════════════════════════════╗")
        print(Fore.YELLOW + "║" + Fore.WHITE + "       SEDANG DALAM PEMELIHARAAN / UPDATE         " + Fore.YELLOW + "║")
        print(Fore.YELLOW + "╠══════════════════════════════════════════════════╣")
        print(Fore.YELLOW + "║ " + Fore.WHITE + "Admin sedang mengunggah pembaruan sistem.       " + Fore.YELLOW + " ║")
        print(Fore.YELLOW + "║ " + Fore.WHITE + "Silakan coba buka kembali beberapa saat lagi.   " + Fore.YELLOW + " ║")
        print(Fore.YELLOW + "╚══════════════════════════════════════════════════╝")
        sys.exit()

    versi_remote = str(data_remote.get("versi", versi_lokal)).strip()
    url_zip = data_remote.get("url_zip", "").strip()
    catatan = data_remote.get("catatan", "Perbaikan sistem dan fitur baru.")

    if not url_zip or parse_versi(versi_remote) <= parse_versi(versi_lokal):
        return

    while True:
        os.system("clear")
        print(Fore.CYAN + "╔══════════════════════════════════════════════════╗")
        print(Fore.CYAN + "║" + Fore.YELLOW + "          UPDATE WAJIB TERSEDIA (GITHUB)          " + Fore.CYAN + "║")
        print(Fore.CYAN + "╠══════════════════════════════════════════════════╣")
        print(Fore.CYAN + "║ " + Fore.WHITE + f"Versi Terpasang : {Fore.RED}{versi_lokal:<31}" + Fore.CYAN + " ║")
        print(Fore.CYAN + "║ " + Fore.WHITE + f"Versi Terbaru   : {Fore.GREEN}{versi_remote:<31}" + Fore.CYAN + " ║")
        print(Fore.CYAN + "╠══════════════════════════════════════════════════╣")
        print(Fore.CYAN + "║ " + Fore.YELLOW + f"Catatan: {catatan[:39]:<39}" + Fore.CYAN + " ║")
        print(Fore.CYAN + "╚══════════════════════════════════════════════════╝")
        print(Fore.WHITE + "\n Data pribadi (token, pesan, config & lisensi) aman.")
        pilihan = input(Fore.GREEN + " ➤ Tekan ENTER untuk update (atau ketik X untuk keluar): ").strip().lower()
        if pilihan == "x":
            sys.exit()

        try:
            konten_zip = unduh_dengan_progres(f"{url_zip}?t={int(time.time())}")

            print(Fore.CYAN + " [2/3] Mengekstrak & memperbarui file sistem...")
            data_dilindungi = {"token.txt", "config.json", ".lisensi.dat", ".lisensi.json", ".aktivasi.dat"}
            with zipfile.ZipFile(io.BytesIO(konten_zip)) as zf:
                for member in zf.infolist():
                    if member.is_dir():
                        continue
                    rel_path = member.filename
                    if rel_path.startswith("post-dc/"):
                        rel_path = rel_path[len("post-dc/"):]
                    if not rel_path:
                        continue
                    target_path = os.path.join(".", rel_path)
                    # Lindungi data pribadi & isi pesan yang sudah ada, tapi tetap buat struktur kategori/sub-kategori jika belum ada
                    if rel_path in data_dilindungi and os.path.exists(target_path):
                        continue
                    if rel_path.startswith("pesan/") and os.path.exists(target_path):
                        continue
                    os.makedirs(os.path.dirname(target_path) or ".", exist_ok=True)
                    with open(target_path, "wb") as f_out:
                        f_out.write(zf.read(member))

            with open(FILE_VERSI_LOKAL, "w", encoding="utf-8") as f_v:
                json.dump({"versi": versi_remote}, f_v, indent=2)

            print(Fore.GREEN + f" [3/3] Berhasil diperbarui ke v{versi_remote}! Memulai ulang...")
            time.sleep(1.5)
            os.execv(sys.executable, [sys.executable] + sys.argv)
        except Exception as e:
            print(Fore.RED + f"\n ✘ Koneksi terputus / gagal unduh: {e}")
            print(Fore.YELLOW + " ↻ Mencoba ulang dalam 3 detik...")
            time.sleep(3)
