import base64, hashlib, hmac, json, os, subprocess, sys, time
from datetime import datetime, timezone, timedelta
import requests
from colorama import Fore

RAHASIA_ADMIN = b"POSTDC_KUNCI_RAHASIA_2026_99812"
KONTAK_ADMIN = "0818-0844-2098"
FILE_LISENSI = ".lisensi.dat"
FILE_AKTIVASI = ".aktivasi.dat"
URL_STATUS_ONLINE = "https://raw.githubusercontent.com/Jayzer-Cyber/Auto-Post-Chanel-DC/main/lisensi_status.json"
LEBAR_KOTAK = 50

def _garis_atas():
    print(Fore.CYAN + "╔" + ("═" * LEBAR_KOTAK) + "╗")

def _garis_tengah():
    print(Fore.CYAN + "╠" + ("═" * LEBAR_KOTAK) + "╣")

def _garis_bawah():
    print(Fore.CYAN + "╚" + ("═" * LEBAR_KOTAK) + "╝")

def _cetak_baris(teks_warna, panjang_asli, rata_tengah=False):
    ruang = LEBAR_KOTAK - 2
    if rata_tengah:
        kiri = max(0, (ruang - panjang_asli) // 2)
        kanan = max(0, ruang - panjang_asli - kiri)
        print(Fore.CYAN + "║ " + (" " * kiri) + teks_warna + (" " * kanan) + Fore.CYAN + " ║")
    else:
        sisa = max(0, ruang - panjang_asli)
        print(Fore.CYAN + "║ " + teks_warna + (" " * sisa) + Fore.CYAN + " ║")

def dapatkan_device_id():
    sumber = []
    for cmd in [["getprop", "ro.serialno"], ["getprop", "ro.product.model"], ["getprop", "ro.build.id"]]:
        try:
            out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL).decode().strip()
            if out and out.lower() != "unknown":
                sumber.append(out)
        except Exception:
            pass
    if not sumber:
        sumber.append(os.path.expanduser("~"))
    h = hashlib.sha256("|".join(sumber).encode()).hexdigest().upper()
    return f"DC-{h[:4]}-{h[4:8]}-{h[8:12]}"

def ambil_waktu_online():
    for url in ["https://discord.com", "https://google.com"]:
        try:
            r = requests.head(url, timeout=3)
            tgl = r.headers.get("Date")
            if tgl:
                dt = datetime.strptime(tgl, "%a, %d %b %Y %H:%M:%S %Z").replace(tzinfo=timezone.utc)
                return int(dt.timestamp())
        except Exception:
            continue
    return None

def cek_server_dan_exp(dev_id, exp_lokal):
    """
    Mengecek status ON/OFF & sinkronisasi exp_ts dari GitHub jika mode_online aktif.
    """
    exp_final = exp_lokal
    try:
        r = requests.get(f"{URL_STATUS_ONLINE}?t={int(time.time())}", timeout=(3, 4))
        if r.status_code != 200:
            return True, "Offline fallback", exp_final
        data = r.json()
        if not data.get("mode_online", True):
            return True, "Mode Offline Aktif", exp_final
        users_map = data.get("users", {})
        if dev_id in users_map:
            info = users_map[dev_id]
            if isinstance(info, dict):
                if not info.get("aktif", True):
                    return False, "Akses perangkat ini dinonaktifkan (OFF) oleh Admin!", exp_final
                srv_exp = int(info.get("exp_ts", 0))
                if srv_exp > 0:
                    exp_final = srv_exp
            elif not bool(info):
                return False, "Akses perangkat ini dinonaktifkan (OFF) oleh Admin!", exp_final
        else:
            return False, "Lisensi dicabut / tidak terdaftar di database Admin!", 0
    except Exception:
        pass
    return True, "OK", exp_final

def muat_atau_buat_exp_lokal(token_str, nilai_angka, waktu_sekarang):
    """
    Mendukung 2 format token:
    - Format Baru (First-Use): nilai_angka <= 36500 (jumlah hari sewa, aktif saat pertama kali dipakai)
    - Format Lama (Fixed-Exp): nilai_angka > 36500 (timestamp kedaluwarsa tetap)
    """
    if nilai_angka > 36500:
        return nilai_angka

    durasi_detik = nilai_angka * 86400
    h_tok = hashlib.sha256(token_str.strip().encode()).hexdigest()[:16]
    if os.path.exists(FILE_AKTIVASI):
        try:
            d = json.load(open(FILE_AKTIVASI, "r", encoding="utf-8"))
            if d.get("hash") == h_tok and int(d.get("exp_ts", 0)) > 0:
                return int(d["exp_ts"])
        except Exception:
            pass

    exp_baru = int(waktu_sekarang) + durasi_detik
    try:
        with open(FILE_AKTIVASI, "w", encoding="utf-8") as f:
            json.dump({"hash": h_tok, "activated_at": int(waktu_sekarang), "exp_ts": exp_baru}, f)
    except Exception:
        pass
    return exp_baru

def verifikasi_token_lisensi(token_str, dev_id, waktu_sekarang):
    try:
        raw = base64.urlsafe_b64decode(token_str.strip().encode()).decode()
        bagian = raw.split("|")
        if len(bagian) != 4:
            return False, "Format token tidak valid.", 0
        t_dev, t_val_str, t_salt, t_sig = bagian
        if t_dev != dev_id:
            return False, "Token ini terdaftar untuk perangkat (HP) lain!", 0
        payload = f"{t_dev}|{t_val_str}|{t_salt}".encode()
        sig_benar = hmac.new(RAHASIA_ADMIN, payload, hashlib.sha256).hexdigest()[:24]
        if not hmac.compare_digest(t_sig, sig_benar):
            return False, "Tanda tangan lisensi palsu atau rusak!", 0

        exp_ts = muat_atau_buat_exp_lokal(token_str, int(t_val_str), waktu_sekarang)
        ok_srv, msg_srv, exp_ts = cek_server_dan_exp(dev_id, exp_ts)
        if not ok_srv:
            return False, msg_srv, exp_ts

        # Simpan pembaruan exp_ts dari server ke lokal (baik diperpanjang maupun dikurangi)
        try:
            h_tok = hashlib.sha256(token_str.strip().encode()).hexdigest()[:16]
            with open(FILE_AKTIVASI, "w", encoding="utf-8") as f:
                json.dump({"hash": h_tok, "activated_at": int(waktu_sekarang), "exp_ts": exp_ts}, f)
        except Exception:
            pass

        if waktu_sekarang >= exp_ts:
            return False, "Masa sewa lisensi Anda telah HABIS!", exp_ts
        return True, "Lisensi Aktif", exp_ts
    except Exception:
        return False, "Kode token rusak atau salah ketik.", 0

def format_sisa_sewa(exp_ts, waktu_sekarang):
    sisa = max(0, int(exp_ts - waktu_sekarang))
    hari = sisa // 86400
    jam = (sisa % 86400) // 3600
    menit = (sisa % 3600) // 60
    detik = sisa % 60
    return f"{hari} Hari {jam} Jam {menit} Menit {detik} Detik"

def ambil_exp_timestamp():
    if os.path.exists(FILE_AKTIVASI):
        try:
            d = json.load(open(FILE_AKTIVASI, "r", encoding="utf-8"))
            if int(d.get("exp_ts", 0)) > 0:
                return int(d["exp_ts"])
        except Exception:
            pass
    if os.path.exists(FILE_LISENSI):
        try:
            saved_token = open(FILE_LISENSI, "r", encoding="utf-8").read().strip()
            raw = base64.urlsafe_b64decode(saved_token.encode()).decode()
            val = int(raw.split("|"))
            if val > 36500:
                return val
        except Exception:
            pass
    return None

def ambil_info_sisa_sewa():
    exp_ts = ambil_exp_timestamp()
    return format_sisa_sewa(exp_ts, time.time()) if exp_ts else None

def cek_akses_lisensi():
    dev_id = dapatkan_device_id()
    waktu_now = ambil_waktu_online()
    if waktu_now is None:
        if os.path.exists(FILE_LISENSI) and os.path.exists(FILE_AKTIVASI):
            waktu_now = int(time.time())
        else:
            print(Fore.RED + "[Error] Gagal memverifikasi waktu server. Pastikan koneksi internet aktif!")
            sys.exit()

    if os.path.exists(FILE_LISENSI):
        try:
            saved_token = open(FILE_LISENSI, "r", encoding="utf-8").read().strip()
            ok, msg, exp_ts = verifikasi_token_lisensi(saved_token, dev_id, waktu_now)
            if ok:
                return format_sisa_sewa(exp_ts, waktu_now)
            else:
                if "palsu" in msg or "perangkat (HP) lain" in msg or "dicabut" in msg:
                    os.remove(FILE_LISENSI)
                    if os.path.exists(FILE_AKTIVASI):
                        os.remove(FILE_AKTIVASI)
                if "dinonaktifkan (OFF)" in msg:
                    os.system("clear")
                    _garis_atas()
                    _cetak_baris(Fore.LIGHTRED_EX + "AKSES DINONAKTIFKAN OLEH ADMIN", 29, rata_tengah=True)
                    _garis_tengah()
                    _cetak_baris(Fore.WHITE + "Status lisensi Anda sedang OFF sementara.", 41)
                    _cetak_baris(Fore.WHITE + "Voucher lama Anda tetap tersimpan aman.", 39)
                    _cetak_baris(Fore.YELLOW + f"Hubungi Admin: {KONTAK_ADMIN[:31]}", len(f"Hubungi Admin: {KONTAK_ADMIN[:31]}"))
                    _garis_bawah()
                    sys.exit()
                print(Fore.RED + f"\n[LISENSI] {msg}")
                time.sleep(2)
        except Exception:
            pass

    while True:
        os.system("clear")
        _garis_atas()
        judul = "AKTIVASI LISENSI AUTO-POST DISCORD"
        _cetak_baris(Fore.WHITE + judul, len(judul), rata_tengah=True)
        _garis_tengah()
        b_dev = f"Device ID HP : {dev_id}"
        _cetak_baris(f"{Fore.WHITE}Device ID HP : {Fore.YELLOW}{dev_id}", len(b_dev))
        kontak_tampil = KONTAK_ADMIN[:31]
        b_adm = f"Kontak Admin : {kontak_tampil}"
        _cetak_baris(f"{Fore.WHITE}Kontak Admin : {Fore.GREEN}{kontak_tampil}", len(b_adm))
        _garis_tengah()
        for idx_p, p in enumerate(["Cara Aktivasi Lisensi:", "1. Salin Device ID HP Anda di atas.", "2. Kirim ke Kontak Admin untuk order sewa.", "3. Tempel Token Lisensi di bawah ini."]):
            _cetak_baris(Fore.CYAN + p if idx_p == 0 else Fore.WHITE + p, len(p))
        _garis_bawah()

        tkn = input(Fore.GREEN + "\n ➤ Tempel Token Lisensi (ketik 'keluar' batal): " + Fore.WHITE).strip()
        if tkn.lower() == "keluar":
            sys.exit()

        waktu_now = ambil_waktu_online() or waktu_now
        ok, msg, exp_ts = verifikasi_token_lisensi(tkn, dev_id, waktu_now)
        if ok:
            with open(FILE_LISENSI, "w", encoding="utf-8") as f:
                f.write(tkn)
            info_sewa = format_sisa_sewa(exp_ts, waktu_now)
            print(Fore.GREEN + f"\n ✔ Aktivasi Berhasil! Masa aktif mulai berjalan: {info_sewa}")
            time.sleep(2)
            return info_sewa
        else:
            print(Fore.RED + f"\n ✘ Gagal: {msg}")
            time.sleep(2)
