#!/bin/bash
cd ~/post-dc

read -p "Masukkan catatan update hari ini: " CATATAN
if [ -z "$CATATAN" ]; then
    echo -e "\033[91m✘ Catatan kosong, penyimpanan dibatalkan.\033[0m"
    exit 1
fi

export CATATAN
python - << 'PYEOF'
import ast, datetime, glob, os

waktu = datetime.datetime.now().strftime("%d-%m-%Y %H:%M WIB")
catatan = os.environ["CATATAN"].strip()
path_ctx = "PROJECT_CONTEXT.md"

# 1. Pindai otomatis semua file .py & fungsi aktif
daftar_modul = []
for py_file in sorted(glob.glob("*.py")):
    try:
        tree = ast.parse(open(py_file, encoding="utf-8").read(), filename=py_file)
        funcs = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and not n.name.startswith("_")]
        daftar_modul.append(f"- `{py_file}`: {', '.join(funcs) if funcs else 'Script utama'}")
    except Exception:
        daftar_modul.append(f"- `{py_file}`: (Gagal memindai)")

# 2. Ambil riwayat log update sebelumnya jika ada
riwayat_lama = []
if os.path.exists(path_ctx):
    isi_lama = open(path_ctx, encoding="utf-8").read()
    if "## 5. Riwayat Log Update" in isi_lama:
        bagian_log = isi_lama.split("## 5. Riwayat Log Update")[1].strip()
        riwayat_lama = [l for l in bagian_log.splitlines() if l.strip().startswith("- [")]

baris_baru = f"- [{waktu}] {catatan}"
semua_riwayat = [baris_baru] + riwayat_lama[:19]  # Simpan 20 riwayat terbaru

konteks = f"""# PROJECT CONTEXT: PETONG AUTO-POST DISCORD (MULTI-TOKEN EDITION)
Terakhir diperbarui: {waktu}

## 1. Struktur Direktori Utama
- `~/post-dc/`          : Direktori aplikasi aktif (Mode Owner Unlimited saat dijalankan lokal via `.py`).
- `~/nextupdate/`      : Cadangan kode sumber `.py` versi pengembangan terbaru.
- `~/switch/switch.py` : Alat pengelola versi bolak-balik (`~/post-dc` <==> `~/nextupdate`).
- `~/lisensi_admin/`   : Penyimpanan token GitHub, modul `lisensi.py`, `updater.py`, & kontrol admin.
- `~/chid/`            : Alat sinkronisasi Channel ID (`chid.py`) & generator link 1x pakai (`bsp.py`).

## 2. Daftar Modul & Fungsi Aktif (`~/post-dc`)
{chr(10).join(daftar_modul)}

## 3. Data Pribadi yang Dijaga Otomatis Saat Switch Versi
- `token.txt`, `config.json`, `pesan/` (13 kategori), `data_user_lisensi.json`, `.lisensi.dat`, `.lisensi.json`, `.aktivasi.dat`, `PROJECT_CONTEXT.md`.

## 4. Perintah Harian Cepat
- Jalankan Aplikasi   : `cd ~/post-dc && python main.py`
- Catat Log Update    : `bash ~/post-dc/log_update.sh`
- Kelola Lisensi User : `python ~/post-dc/buat_lisensi.py`
- Sinkron Channel ID  : `python ~/chid/chid.py`
- Buat Link 1x Pakai  : `python ~/chid/bsp.py`
- Rilis ke GitHub     : `bash ~/post-dc/update_paket.sh`

## 5. Riwayat Log Update
{chr(10).join(semua_riwayat)}
"""

open(path_ctx, "w", encoding="utf-8").write(konteks)
print(f"\033[92m✔ PROJECT_CONTEXT.md diperbarui: {baris_baru}\033[0m")
PYEOF

cp ~/post-dc/PROJECT_CONTEXT.md ~/nextupdate/PROJECT_CONTEXT.md
