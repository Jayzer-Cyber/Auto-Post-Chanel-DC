from main_app import jalankan
if __name__ == '__main__':
    jalankan()
