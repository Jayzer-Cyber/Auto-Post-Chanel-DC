import os
import re
import shutil
import sys
import threading
import time
import unicodedata
from colorama import Fore, init

init(autoreset=True)

KONTAK_ADMIN = "0818-0844-2098"
_ANIM_LOCK = threading.Lock()


def bersihkan_layar():
    os.system("clear")


def bersihkan_konten():
    esc = chr(27)
    sys.stdout.write(f"{esc}[13;1H{esc}[J")
    sys.stdout.flush()


def _render_baris_art(fase=0.0):
    esc = chr(27)
    baris_art = [
        "   _____  ______ _______ ____  _   _  _____      ",
        "  |  __ \\|  ____|__   __/ __ \\| \\ | |/ ____|     ",
        "  | |__) | |__     | | | |  | |  \\| | |  __      ",
        "  |  ___/|  __|    | | | |  | | . ` | | |_ |     ",
        "  | |    | |____   | | | |__| | |\\  | |__| |     ",
        "  |_|    |______|  |_|  \\____/|_| \\_|\\_____|     ",
    ]
    titik = [
        (50, 225, 80),
        (165, 235, 50),
        (250, 210, 40),
        (255, 130, 45),
        (240, 75, 75),
    ]
    n_titik = len(titik) - 1
    hasil = []
    for r_idx, baris in enumerate(baris_art):
        segmen = []
        for c_idx, ch in enumerate(baris):
            if ch == " ":
                segmen.append(" ")
            else:
                pos = (r_idx / 5.0) * 0.85 + (c_idx / 48.0) * 0.15
                t = min(max(pos, 0.0), 0.9999)
                seg = t * n_titik
                i = int(seg)
                f = seg - i
                (r1, g1, b1), (r2, g2, b2) = titik[i], titik[i + 1]
                r = int(r1 + (r2 - r1) * f)
                g = int(g1 + (g2 - g1) * f)
                b = int(b1 + (b2 - b1) * f)
                segmen.append(f"{esc}[1;38;2;{r};{g};{b}m{ch}")
        hasil.append(f"{Fore.CYAN}║ {''.join(segmen)}{esc}[0m{Fore.CYAN}║")
    return hasil


def _bangun_teks_header(fase=0.0):
    esc = chr(27)
    buf = [f"{Fore.CYAN}╔══════════════════════════════════════════════════╗{esc}[K"]
    for b in _render_baris_art(fase):
        buf.append(b + f"{esc}[K")
    buf.append(f"{Fore.CYAN}╠══════════════════════════════════════════════════╣{esc}[K")
    buf.append(f"{Fore.CYAN}║ {Fore.LIGHTGREEN_EX}Author: Petong (Multi-Token Edition)            {Fore.CYAN} ║")
    buf.append(f"{Fore.CYAN}║ {Fore.LIGHTCYAN_EX}Kontak Admin : {Fore.WHITE}{KONTAK_ADMIN[:33]:<33}{Fore.CYAN} ║")
    buf.append(f"{Fore.CYAN}║ {Fore.LIGHTRED_EX}PERINGATAN : TIDAK UNTUK DI PERJUAL-BELIKAN     {Fore.CYAN} ║")
    buf.append(f"{Fore.CYAN}╚══════════════════════════════════════════════════╝{esc}[K")
    return chr(10).join(buf)


def hentikan_animasi_banner():
    pass


def tampilkan_banner():
    esc = chr(27)
    nl = chr(10)
    header_str = _bangun_teks_header(0.0)
    try:
        from bg_state import BG_STATE
        is_aktif = BG_STATE.get("aktif", False)
    except Exception:
        is_aktif = False

    if is_aktif:
        status_txt = f"{Fore.GREEN}● AKTIF (Berjalan di Background)"
    else:
        status_txt = f"{Fore.LIGHTRED_EX}● TIDAK AKTIF (Belum Berjalan)"

    bar_bg = (
        f"{Fore.CYAN}╔══════════════════════════════════════════════════╗{nl}"
        f"{Fore.CYAN}║ {Fore.WHITE}⚡ AUTO-POST: {status_txt}{' ' * (3 if is_aktif else 5)}{Fore.CYAN}║{nl}"
        f"{Fore.CYAN}╚══════════════════════════════════════════════════╝{nl}"
    )

    with _ANIM_LOCK:
        sys.stdout.write(f"{esc}[1;1H{header_str}{nl}{esc}[13;1H{bar_bg}{esc}[16;1H")
        sys.stdout.flush()


def format_waktu(detik):
    jam, sisa = divmod(int(detik), 3600)
    menit, dtk = divmod(sisa, 60)
    hasil = [
        f"{jam} Jam" if jam else "",
        f"{menit} Menit" if menit else "",
        f"{dtk} Detik" if (dtk or not (jam or menit)) else "",
    ]
    return " ".join(filter(None, hasil))


def format_jam_menit_detik(detik):
    if detik <= 0:
        return "00:00:00"
    jam, sisa = divmod(int(detik), 3600)
    menit, dtk = divmod(sisa, 60)
    return f"{jam:02d}:{menit:02d}:{dtk:02d}"


def _lebar_vis_antrean(teks):
    bersih = re.sub(r'\033\[[0-9;]*[mGK]', '', teks)
    w = 0
    for ch in bersih:
        if unicodedata.combining(ch) or ch == '\ufe0f':
            continue
        if ord(ch) >= 0x1F300 or unicodedata.east_asian_width(ch) in ('W', 'F'):
            w += 2
        else:
            w += 1
    return w


def _potong_vis_antrean(teks, maks_lebar):
    hasil = ""
    w = 0
    for ch in teks:
        if unicodedata.combining(ch) or ch == '\ufe0f':
            hasil += ch
            continue
        cw = 2 if (ord(ch) >= 0x1F300 or unicodedata.east_asian_width(ch) in ('W', 'F')) else 1
        if w + cw > maks_lebar:
            break
        hasil += ch
        w += cw
    return hasil


def cetak_daftar_status(channel_configs):
    esc = chr(27)
    sekarang = time.time()
    buf = [
        f"{Fore.CYAN}╔══════════════════════════════════════════════════╗",
        f"{Fore.CYAN}║ {Fore.YELLOW}📋 STATUS ANTREAN & CHANNEL AKTIF ({len(channel_configs)} CH){esc}[52G{Fore.CYAN}║",
        f"{Fore.CYAN}╠══════════════════════════════════════════════════╣",
    ]

    for ch_id, cfg in channel_configs.items():
        status = cfg.get("status", "siap")
        if status == "proses":
            tag = Fore.YELLOW + "[⟳]"
        elif status == "sukses":
            tag = Fore.LIGHTGREEN_EX + "[✓]"
        elif status == "gagal":
            tag = Fore.LIGHTRED_EX + "[✗]"
        else:
            tag = Fore.CYAN + "[•]"

        sisa = cfg["waktu_kirim_berikutnya"] - sekarang
        sisa_limit_dc = cfg.get("waktu_limit_dc", 0) - sekarang

        if status == "proses":
            info_jeda = Fore.YELLOW + "Mengirim..."
        elif sisa_limit_dc > 0:
            tag = Fore.LIGHTRED_EX + "[✗]"
            info_jeda = Fore.LIGHTRED_EX + f"Limit DC: {format_jam_menit_detik(sisa_limit_dc)}"
        elif sisa > 0:
            tag = Fore.LIGHTGREEN_EX + "[✓]"
            info_jeda = Fore.LIGHTGREEN_EX + f"Jeda: {format_jam_menit_detik(sisa)}"
        else:
            tag = Fore.CYAN + "[•]"
            info_jeda = Fore.CYAN + "Siap Kirim"

        nama_bersih = cfg["nama_file"].replace(".txt", "")
        maks_nama = max(10, 42 - _lebar_vis_antrean(info_jeda))
        nama_rapi = _potong_vis_antrean(nama_bersih, maks_nama)
        kiri = f"{tag} {Fore.WHITE}{nama_rapi}"
        spasi = " " * max(1, 48 - _lebar_vis_antrean(kiri) - _lebar_vis_antrean(info_jeda))
        buf.append(f"{Fore.CYAN}║ {kiri}{spasi}{info_jeda}{esc}[52G{Fore.CYAN}║")

    buf.append(f"{Fore.CYAN}╚══════════════════════════════════════════════════╝")
    print("\n".join(buf) + "\n", flush=True)



def _cek_tombol_bg():
    try:
        from bg_state import BG_STATE, baca_tombol_nonblock
        cmd = baca_tombol_nonblock()
        if cmd == "m":
            BG_STATE["layar_auto"] = False
            return "m"
        elif cmd == "q":
            BG_STATE["stop_event"].set()
            BG_STATE["layar_auto"] = False
            return "q"
    except Exception:
        pass
    return None


def cetak_kotak_target(urutan_str, label, info_retry, ch_id, nomor_token):
    esc = chr(27)
    nama_potong = _potong_vis_antrean(f"{label}{info_retry}", 26)
    kiri = f"{Fore.YELLOW}🎯 {urutan_str} {Fore.WHITE}{nama_potong}"
    kanan = f"{Fore.CYAN}T#{nomor_token:02d}"
    spasi = " " * max(1, 48 - _lebar_vis_antrean(kiri) - _lebar_vis_antrean(kanan))
    print(f"{Fore.CYAN}╔══════════════════════════════════════════════════╗")
    print(f"{Fore.CYAN}║ {kiri}{spasi}{kanan}{esc}[52G{Fore.CYAN}║")
    print(f"{Fore.CYAN}╟──────────────────────────────────────────────────╢")
    print(f"{Fore.CYAN}║ {Fore.CYAN}Memulai proses pengiriman...{esc}[52G{Fore.CYAN}║")
    print(f"{Fore.CYAN}╟──────────────────────────────────────────────────╢")
    print(f"{Fore.CYAN}║ {Fore.YELLOW}[M+Enter]{Fore.WHITE} Menu Utama    {Fore.RED}[0+Enter]{Fore.WHITE} Keluar Program {Fore.CYAN}║")
    print(f"{Fore.CYAN}╚══════════════════════════════════════════════════╝")
    print(f"{Fore.CYAN}╔══════════════════════════════════════════════════╗")
    print(f"{Fore.CYAN}║ {Fore.GREEN}➤ Ketik [M] Menu / [0] Keluar: {' ' * 17}{Fore.CYAN} ║")
    sys.stdout.write(f"{Fore.CYAN}╚══════════════════════════════════════════════════╝{esc}[1A{esc}[34G")
    sys.stdout.flush()


def _cek_kunci_otomatis_utils():
    try:
        from lisensi import ambil_exp_timestamp
        exp_ts = ambil_exp_timestamp()
        if exp_ts and time.time() >= exp_ts:
            bersihkan_layar()
            tampilkan_banner()
            print(Fore.CYAN + "╔══════════════════════════════════════════════════╗")
            print(Fore.CYAN + "║ " + Fore.LIGHTRED_EX + "⛔ MASA SEWA HABIS - AUTO-POST DIHENTIKAN!       " + Fore.CYAN + "║")
            print(Fore.CYAN + "║ " + Fore.WHITE + "Silakan perpanjang voucher ke Admin.             " + Fore.CYAN + "║")
            print(Fore.CYAN + "╚══════════════════════════════════════════════════╝")
            os._exit(0)
    except ImportError:
        pass


def jeda_antar_channel_animasi(detik, channel_configs, hasil_notif=""):
    esc = chr(27)
    spinner = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    selesai = time.time() + detik
    idx = 0
    notif_bersih = re.sub(r'\033\[[0-9;]*[mGK]', '', hasil_notif).strip()
    is_gagal = "[GAGAL]" in notif_bersih or "LIMIT" in notif_bersih.upper()
    warna_notif = Fore.LIGHTRED_EX if is_gagal else Fore.LIGHTGREEN_EX
    ikon_notif = "✗" if is_gagal else "✓"
    ringkas_notif = notif_bersih.replace("[SUKSES]", "").replace("[GAGAL]", "").strip()
    ringkas_notif = re.sub(r'\s*Terkirim!.*$', '', ringkas_notif, flags=re.IGNORECASE).strip()
    ringkas_notif = re.sub(r'\s*\(Cooldown.*$', '', ringkas_notif, flags=re.IGNORECASE).strip()

    while time.time() < selesai:
        _cek_kunci_otomatis_utils()
        sisa = max(0, int(selesai - time.time()))
        sp = spinner[idx % len(spinner)]
        if ringkas_notif:
            sisa_ruang = max(8, 35 - len(str(sisa)))
            potong_n = _potong_vis_antrean(ringkas_notif, sisa_ruang)
            isi = f"{Fore.CYAN}{sp} Jeda {Fore.YELLOW}{sisa}d {Fore.WHITE}| {warna_notif}{ikon_notif} {potong_n}"
        else:
            isi = f"{Fore.CYAN}{sp} Jeda antar channel: {Fore.YELLOW}{sisa} detik"
        if _cek_tombol_bg():
            return
        try:
            from bg_state import BG_STATE
            ketik_skrg = BG_STATE.get("input_buf", "")
        except Exception:
            ketik_skrg = ""
        sisa_spasi_in = max(0, 17 - len(ketik_skrg))
        kol_in = min(50, 34 + len(ketik_skrg))
        sys.stdout.write(
            f"{esc}[5A\r{esc}[J{Fore.CYAN}║ {isi}{esc}[K{esc}[52G{Fore.CYAN}║\n"
            f"{Fore.CYAN}╟──────────────────────────────────────────────────╢\n"
            f"{Fore.CYAN}║ {Fore.YELLOW}[M+Enter]{Fore.WHITE} Menu Utama    {Fore.RED}[0+Enter]{Fore.WHITE} Keluar Program {Fore.CYAN}║\n"
            f"{Fore.CYAN}╚══════════════════════════════════════════════════╝\n"
            f"{Fore.CYAN}╔══════════════════════════════════════════════════╗\n"
            f"{Fore.CYAN}║ {Fore.GREEN}➤ Ketik [M] Menu / [0] Keluar: {Fore.WHITE}{ketik_skrg}{' ' * sisa_spasi_in}{Fore.CYAN} ║\n"
            f"{Fore.CYAN}╚══════════════════════════════════════════════════╝{esc}[1A{esc}[{kol_in}G"
        )
        sys.stdout.flush()
        idx += 1
        time.sleep(0.25)


def tampilkan_antrean_dan_tunggu(channel_configs, jadwal_terdekat):
    esc = chr(27)
    spinner = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    idx = 0
    last_size = shutil.get_terminal_size((52, 24))
    header_statis = _bangun_teks_header(0.0)

    sys.stdout.write(f"{esc}[2J{esc}[3J{esc}[H")
    sys.stdout.flush()

    while time.time() < jadwal_terdekat:
        if _cek_tombol_bg():
            return
        _cek_kunci_otomatis_utils()
        cur_size = shutil.get_terminal_size((52, 24))
        prefix_clear = ""
        if cur_size != last_size:
            last_size = cur_size
            prefix_clear = f"{esc}[2J{esc}[3J"

        sekarang = time.time()
        urutan = sorted(
            channel_configs.items(), key=lambda x: x[1]["waktu_kirim_berikutnya"]
        )

        sp = spinner[idx % len(spinner)]
        buf = [
            header_statis,
            f"{Fore.CYAN}╔══════════════════════════════════════════════════╗{esc}[K",
            f"{Fore.CYAN}║ {Fore.YELLOW}{sp} ANTREAN JADWAL (TERDEKAT -> TERLAMA){esc}[K{esc}[52G{Fore.CYAN}║{esc}[K",
            f"{Fore.CYAN}╠══════════════════════════════════════════════════╣{esc}[K",
        ]

        for i, (ch_id, cfg) in enumerate(urutan, start=1):
            sisa = cfg["waktu_kirim_berikutnya"] - sekarang
            sisa_limit_dc = cfg.get("waktu_limit_dc", 0) - sekarang
            label = cfg["nama_file"].replace(".txt", "")
            bintang = f"{Fore.YELLOW}*" if i == 1 else " "

            if sisa <= 0:
                status = f"{Fore.CYAN}SIAP KIRIM!{bintang}"
            elif sisa_limit_dc > 0:
                status = f"{Fore.RED}{format_jam_menit_detik(sisa_limit_dc)} Jeda DC{bintang}"
            else:
                status = f"{Fore.GREEN}{format_jam_menit_detik(sisa)} Jeda File{bintang}"

            maks_label = max(10, 42 - _lebar_vis_antrean(status))
            label_rapi = _potong_vis_antrean(label, maks_label)
            kiri = f"{Fore.CYAN}{i:02d}. {Fore.WHITE}{label_rapi}"
            spasi = " " * max(1, 48 - _lebar_vis_antrean(kiri) - _lebar_vis_antrean(status))
            buf.append(f"{Fore.CYAN}║ {kiri}{spasi}{status}{esc}[K{esc}[52G{Fore.CYAN}║{esc}[K")

        buf.append(f"{Fore.CYAN}╟──────────────────────────────────────────────────╢{esc}[K")
        buf.append(
            f"{Fore.CYAN}║ {Fore.RED}Merah=Jeda DC  {Fore.GREEN}Hijau=Jeda File  {Fore.WHITE}*=Next{esc}[K{esc}[52G{Fore.CYAN}║{esc}[K"
        )
        try:
            from bg_state import BG_STATE
            ketik_skrg = BG_STATE.get("input_buf", "")
        except Exception:
            ketik_skrg = ""
        prompt_bg = f"➤ Ketik [M] Menu / [0] Keluar: {ketik_skrg}"
        sisa_bg = max(0, 48 - len(prompt_bg))
        buf.append(f"{Fore.CYAN}╟──────────────────────────────────────────────────╢{esc}[K")
        buf.append(f"{Fore.CYAN}║ {Fore.YELLOW}[M+Enter]{Fore.WHITE} Menu Utama    {Fore.RED}[0+Enter]{Fore.WHITE} Keluar Program {Fore.CYAN}║{esc}[K")
        buf.append(f"{Fore.CYAN}╚══════════════════════════════════════════════════╝{esc}[K")
        buf.append(f"{Fore.CYAN}╔══════════════════════════════════════════════════╗{esc}[K")
        buf.append(f"{Fore.CYAN}║ {Fore.GREEN}➤ Ketik [M] Menu / [0] Keluar: {Fore.WHITE}{ketik_skrg}{' ' * sisa_bg}{Fore.CYAN} ║{esc}[K")
        buf.append(f"{Fore.CYAN}╚══════════════════════════════════════════════════╝{esc}[K")

        kol_kursor = min(50, 34 + len(ketik_skrg))
        frame = f"{prefix_clear}{esc}[H" + "\n".join(buf) + f"{esc}[J{esc}[1A{esc}[{kol_kursor}G"
        sys.stdout.write(frame)
        sys.stdout.flush()
        idx += 1
        time.sleep(1)


def tampilkan_progress_kirim(persen, keterangan, warna=Fore.CYAN):
    esc = chr(27)
    panjang_bar = 14
    terisi = int(panjang_bar * persen // 100)
    bar = "█" * terisi + "░" * (panjang_bar - terisi)
    ket_bersih = re.sub(r'\033\[[0-9;]*[mGK]', '', keterangan).strip()
    if "SUKSES TERKIRIM" in ket_bersih.upper():
        ket_bersih = "SUKSES TERKIRIM!"
    elif "GAGAL" in ket_bersih.upper():
        ket_bersih = ket_bersih.split("(")[0].strip()
    ket_potong = _potong_vis_antrean(ket_bersih, 23)
    isi = f"{warna}[{bar}] {persen:3d}% {Fore.WHITE}| {warna}{ket_potong}"
    _cek_tombol_bg()
    try:
        from bg_state import BG_STATE
        ketik_skrg = BG_STATE.get("input_buf", "")
    except Exception:
        ketik_skrg = ""
    sisa_spasi_in = max(0, 17 - len(ketik_skrg))
    kol_in = min(50, 34 + len(ketik_skrg))
    sys.stdout.write(
        f"{esc}[5A\r{esc}[J{Fore.CYAN}║ {isi}{esc}[K{esc}[52G{Fore.CYAN}║\n"
        f"{Fore.CYAN}╟──────────────────────────────────────────────────╢\n"
        f"{Fore.CYAN}║ {Fore.YELLOW}[M+Enter]{Fore.WHITE} Menu Utama    {Fore.RED}[0+Enter]{Fore.WHITE} Keluar Program {Fore.CYAN}║\n"
        f"{Fore.CYAN}╚══════════════════════════════════════════════════╝\n"
        f"{Fore.CYAN}╔══════════════════════════════════════════════════╗\n"
        f"{Fore.CYAN}║ {Fore.GREEN}➤ Ketik [M] Menu / [0] Keluar: {Fore.WHITE}{ketik_skrg}{' ' * sisa_spasi_in}{Fore.CYAN} ║\n"
        f"{Fore.CYAN}╚══════════════════════════════════════════════════╝{esc}[1A{esc}[{kol_in}G"
    )
    sys.stdout.flush()
