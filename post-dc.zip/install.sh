#!/bin/bash
pkg update -y && pkg upgrade -y
pkg install python git unzip termux-api -y
pip install --upgrade pip
pip install colorama requests
echo "✅ Instalasi selesai! Jalankan program dengan: python main.py"
